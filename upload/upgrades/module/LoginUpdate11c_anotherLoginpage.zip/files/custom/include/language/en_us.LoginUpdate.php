<?php

$GLOBALS['app_list_strings']['customer_id_list']=array (
  '' => '',
  'new' => 'Automatically create a new Customer ID Group',
  'old' => 'Manually select a Customer ID Group after saving',
);
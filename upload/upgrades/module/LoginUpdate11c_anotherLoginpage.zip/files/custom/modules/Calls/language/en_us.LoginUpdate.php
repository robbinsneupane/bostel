<?php
// created: 2019-07-21 13:41:40
$mod_strings = array (
  'LBL_SECURITYGROUPS_SUBPANEL_TITLE' => 'Customer Groups',
);
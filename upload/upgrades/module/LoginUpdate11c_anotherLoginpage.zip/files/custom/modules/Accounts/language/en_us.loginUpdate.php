<?php
// created: 2019-07-21 13:50:50
$mod_strings = array (
  'LBL_SECURITYGROUPS_SUBPANEL_TITLE' => 'Customer Groups',
  'LBL_CREATE_CUSTOMER_ID_C' => 'Customer ID',
  'LBL_CUSTOMER_ID_C' => 'Customer ID Number',
);
<?php
// created: 2019-07-06 12:31:04
$mod_strings['LBL_GROUP'] = 'Customer ID';

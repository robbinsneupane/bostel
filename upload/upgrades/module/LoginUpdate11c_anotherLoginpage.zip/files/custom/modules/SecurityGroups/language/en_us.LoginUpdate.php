<?php
// created: 2019-07-21 13:36:20
$mod_strings = array (
  'LBL_DESCRIPTION' => 'Customer Group Name',
  'LBL_NAME' => 'Customer Group ID',
  'LBL_EDITVIEW_PANEL1' => 'New Panel 1',
  'LBL_DETAILVIEW_PANEL1' => 'Dates',
);
<?php
//auto-generated file DO NOT EDIT
$layout_defs['Accounts']['subpanel_setup']['securitygroups']['override_subpanel_name'] = 'Account_subpanel_securitygroups';
?>
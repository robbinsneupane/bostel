<?php
 // created: 2019-07-21 13:34:38
$dictionary['SecurityGroup']['fields']['name']['default']='Will be filled in automatically on save';
$dictionary['SecurityGroup']['fields']['name']['required']=false;
$dictionary['SecurityGroup']['fields']['name']['inline_edit']='';
$dictionary['SecurityGroup']['fields']['name']['duplicate_merge']='disabled';
$dictionary['SecurityGroup']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['SecurityGroup']['fields']['name']['merge_filter']='disabled';
$dictionary['SecurityGroup']['fields']['name']['unified_search']=false;

 ?>
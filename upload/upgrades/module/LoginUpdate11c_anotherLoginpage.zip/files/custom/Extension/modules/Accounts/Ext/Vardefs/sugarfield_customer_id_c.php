<?php
 // created: 2019-07-21 13:50:50
$dictionary['Account']['fields']['customer_id_c']['inline_edit']='';
$dictionary['Account']['fields']['customer_id_c']['labelValue']='Customer ID';

 ?>
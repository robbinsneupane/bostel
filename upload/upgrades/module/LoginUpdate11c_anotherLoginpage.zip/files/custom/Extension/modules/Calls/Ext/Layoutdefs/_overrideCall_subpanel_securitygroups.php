<?php
//auto-generated file DO NOT EDIT
$layout_defs['Calls']['subpanel_setup']['securitygroups']['override_subpanel_name'] = 'Call_subpanel_securitygroups';
?>
<?php
//PHASE#1
$hook_array['before_save'][] = Array(
	1,
	'Add ID to Security Group',
	'custom/modules/SecurityGroups/before_save_hook.php',
	'SecurityGroupsBeforeSaveHook',
	'addIDToGroup');

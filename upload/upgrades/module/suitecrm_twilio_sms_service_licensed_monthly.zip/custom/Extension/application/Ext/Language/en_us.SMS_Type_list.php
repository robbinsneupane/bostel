<?php
/*
 * Created by Taction Software LLC - Copyright 2018
 * Website: www.tactionsoftware.com/
 * Mail: info@tactionsoftware.com
 * @Author:Akanksha Srivastava
 * Description: SMS Type list for action in Workflow language file
 * 
 */

$app_list_strings['aow_sms_type_list'] = array (

'Mobile Number' => 'Mobile Number',
'Record SMS' => 'Record SMS',
'Related Field' => 'Related Field',
'Specify User' => 'User',
'Users' => 'Users',
);

?>

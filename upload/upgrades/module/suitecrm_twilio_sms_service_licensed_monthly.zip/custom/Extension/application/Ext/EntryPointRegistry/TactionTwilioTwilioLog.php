<?php
/*
 * Created by Taction Software LLC - Copyright 2018
 * Website: www.tactionsoftware.com/
 * Mail: info@tactionsoftware.com
 * @Author:Akanksha Srivastava
 * Description: EntryPoint to View Twilio Log
 * 
 */
    $entry_point_registry['TwilioLog'] = array(
        'file' => 'custom/modules/Administration/TwilioLog.php',
        'auth' => true
    );

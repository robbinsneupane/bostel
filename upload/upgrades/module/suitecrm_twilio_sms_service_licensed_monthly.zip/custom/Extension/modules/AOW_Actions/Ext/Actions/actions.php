<?php
/*
 * Created by Taction Software LLC - Copyright 2018
 * Website: www.tactionsoftware.com/
 * Mail: info@tactionsoftware.com
 * @Author:Akanksha Srivastava
 * Description: Adding Send SMS Link to Workflow Action
 * 
 */

    
    $aow_actions_list[]='SendSMS';
    



<?php
/*
 * Created by Taction Software LLC - Copyright 2018
 * Website: www.tactionsoftware.com/
 * Mail: info@tactionsoftware.com
 * @Author:Akanksha Srivastava
 * Description: Language file for Send SMS action
 * 
 */

$mod_strings['LBL_INDIVIDUAL_SMS'] 		= 'Send Individual Sms';
$mod_strings['LBL_SMS_TEMPLATE'] 		= 'Sms Template';
$mod_strings['LBL_EDIT_SMS_TEMPLATE'] 	= 'Edit';
$mod_strings['LBL_SMS'] 				= 'Sms To';
$mod_strings['LBL_SENDSMS'] 			= 'Send sms';
$mod_strings['LBL_CREATE_SMS_TEMPLATE'] = 'Create';

<?php
/*
 * Created by Taction Software LLC - Copyright 2018
 * Website: www.tactionsoftware.com/
 * Mail: info@tactionsoftware.com
 * @Author:Akanksha Srivastava
 * Description: Language file
 * 
 */
  $mod_strings['LBL_TWILIO_SETTING'] = 'Twilio Configuration';
  $mod_strings['TWILIO_SETTINGS'] = 'Twilio Account Setting';
  $mod_strings['LBL_TWILIO_DESCRIPTION'] = 'Manage Twilio Setting';
  $mod_strings['LBL_TWILIO_SETTING_TITLE'] = 'Twilio Account Setting';
  $mod_strings['TWILIO_ACCOUNT_SID'] = 'Account SID';
  $mod_strings['TWILIO_AUTH_TOKEN'] = 'Auth Token';
  $mod_strings['TWILIO_PHONE_NO'] = 'Twilio Phone no';
  $mod_strings['LBL_TWILIO_LOG'] = 'View Twilio Log';
  $mod_strings['LBL_TWILIO_LOG_DESCRIPTION'] = 'Twilio Log';
  $mod_strings['LBL_TWILIO_MESSAGE_LOG_SETTING'] = 'Enable Modules to view Message Log';
  $mod_strings['LBL_ENABLE_MODULES'] = 'Select Modules';
  $mod_strings['LBL_CONFIG_SCHEDULER_TRIALS'] = 'Configure the limit of scheduler trials';
  $mod_strings['LBL_LIMIT_OF_SCHEDULER_TRIALS'] = 'Limit';

<?php
/*
 * Created by Taction Software LLC - Copyright 2018
 * Website: www.tactionsoftware.com/
 * Mail: info@tactionsoftware.com
 * @Author:Akanksha Srivastava
 * Description: Language file for Custom Scheduler which is sending undelivered sms
 * 
 */
 
$mod_strings['LBL_TWILIO_SMS_SCHEDULER'] = 'Twilio Sms Scheduler'
